#/usr/bin/env python

# pound comment

import time
print('Hello.  The time is %f Unix epoch.' % (time.time()))  # inline comment
print(f'f-string')

"""
Docstring,
  also counted as comment.
"""

'''
Single
  Quoted
    Docstring'''
