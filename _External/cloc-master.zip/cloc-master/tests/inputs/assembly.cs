using System.Reflection;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

[assembly: AssemblyCompany("eventIS Interactive Solutions BV")]
[assembly: AssemblyProduct("Traxis")]
[assembly: AssemblyCopyright("Copyright <A9> 2006 - 2008 eventIS Interactive Solutions BV")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyTrademark("")]

// Values in this file will be overwritten by the build process

[assembly: AssemblyVersion("0.0.0.0")]
[assembly: AssemblyFileVersion("0.0.0.0")]
[assembly: AssemblyInformationalVersion("0.0.0.0")]
